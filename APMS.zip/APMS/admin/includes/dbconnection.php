<?php
$con=mysqli_connect("localhost", "princess.balogun", "ZyxB09$$", "webtech_fall2024_princess_balogun");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
