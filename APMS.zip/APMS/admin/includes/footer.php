  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    
                    <div class="col-sm-6 text-center">
                        Ashesi Parking Management System
                    </div>
                </div>
            </div>
        </footer>